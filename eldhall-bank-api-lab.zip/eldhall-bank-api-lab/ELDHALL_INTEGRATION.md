# Eldhall integration proof

This FastAPI application is a separate directory, D:/eldhall-bank-api-lab. Its business code contains no MCP server or Eldhall dependency. The real HTTP OpenAPI snapshot was imported by Eldhall's existing reviewed OpenAPI adapter. Only synthetic data and effects are used.

Running addresses: FastAPI http://127.0.0.1:8101/docs ; MCP Streamable HTTP http://127.0.0.1:8102/mcp ; Eldhall http://127.0.0.1:5173/operator/integrations?lang=uk . MCP requires the separate service credential and is intended for Eldhall, not unauthenticated browser use.

From this directory, start the independent backend with:

```powershell
.venv/Scripts/python.exe -m bank_api_lab
```

The actual snapshot is `.runtime/openapi.json`; the explicit review overlay is `review.json`. From D:/comp-prep, the import used was:

```powershell
& D:/eldhall-bank-api-lab/.runtime/mcp-venv/Scripts/python.exe -m support_mcp.import_openapi D:/eldhall-bank-api-lab/.runtime/openapi.json D:/eldhall-bank-api-lab/review.json --out D:/eldhall-bank-api-lab/.runtime/manifest.json --normalized-spec D:/eldhall-bank-api-lab/.runtime/normalized.openapi.json --report D:/eldhall-bank-api-lab/.runtime/import-report.json
```

Outputs already exist. The manifest exposes get_account, get_balance, list_transactions, freeze_card and close_account, plus the adapter's connector metadata tool. Customer/business scope is injected by Eldhall and enforced again by this service. The two write definitions bind Idempotency-Key to the durable proposal identity and project only reviewed output fields.

The private local setup helpers are in D:/comp-prep/.omc/dev-runtime. `external-mcp-prepare.mts` generated `.runtime/support.config.json` using the actual manifest, disabled/default-deny initially. `external-mcp-sidecar.py` runs the existing generic support_mcp.server.build_app adapter:

```powershell
$env:NO_PROXY = '127.0.0.1,localhost'
& D:/eldhall-bank-api-lab/.runtime/mcp-venv/Scripts/python.exe D:/comp-prep/.omc/dev-runtime/external-mcp-sidecar.py
```

The current bank launcher uses its existing explicitly selected local PostgreSQL/Google credential file, plus `--catalog-config D:/eldhall-bank-api-lab/.runtime/support.config.json --catalog-credentials-file D:/eldhall-bank-api-lab/.runtime/credentials.env`. The authoritative full command/current process identities are in D:/comp-prep/.omc/handoffs/local-runtime-current.json. It is limited to the existing synthetic bank and the two loopback services. These ignored helpers are a local acceptance harness; general deployments use D:/comp-prep/docs/OPENAPI_QUICKSTART.md.

The operator reviewed the exact five definitions, selected auto for reads, ask for freeze_card, deny for close_account, then activated the live matching catalog. Modes persist in Eldhall PostgreSQL. The generated config intentionally remains disabled/default-deny as bootstrap input; startup does not overwrite operator policy. The live Auto→Deny→Auto read-mode check advanced policy revisions4→5→6 without restarting services.

Real gemini-3.1-flash-lite results:

- Successful balance retake: case534f2ca4-b468-4a1e-876c-54ee861ea974, actual external get_balance for Taras returned3754217centsUAH and the customer received37 542,17UAH/source external-fastapi-lab.
- Ask retake: caseacf450d6-3bed-48c7-b330-378d0cd0a972, proposal6dd3c11f-b824-4fcb-a713-3ce3b6ffad55. Pending and approval alone caused0external effects. Separate execute caused1synthetic Marta-card freeze; repeat execute returned409 and caused no second effect.
- Deny: casecf3c404e-63c5-4707-8281-a66b9ee174ec handed off without closing an account. The trusted TS catalog facade also rejected forced denied calls before dispatch; the external journal stayed byte-for-byte unchanged.

Two original quality failures remain recorded, not relabelled as successes: a correct MCP balance was replaced by a native billing reply template (fixed in private PR27), and the first card request followed stale native-only capability wording (an additive custom/bank-lab-mcp-operations skill clarified the current advertised inventory; the original eight skills remain unchanged).

Evidence is private in D:/comp-prep/.omc/artifacts/external-fastapi-mcp and related source/review receipts. The journal tracks successful reads, committed mutations and idempotent replays; it does not count every unsuccessful HTTP attempt. All250 pretest PostgreSQL rows, including the original111-row baseline, were preserved by exact row-hash multiset checks. No actual bank/payment provider, public server, publication or production deployment is involved.
