import json
import sqlite3
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from contextlib import closing
from pathlib import Path
from uuid import uuid4

from fastapi.testclient import TestClient

from bank_api_lab.app import create_app
from bank_api_lab.config import BUSINESS_ID, ROOT, SOURCE
from bank_api_lab.store import Store

TOKEN = "test-fixture-bearer-only-not-a-real-service-token"
TARAS = "b2000000-0000-4000-8000-000000000002"
MARTA = "b2000000-0000-4000-8000-000000000004"
ANDRII = "b2000000-0000-4000-8000-000000000005"


class BankingLabTests(unittest.TestCase):
    def setUp(self):
        parent = ROOT / ".runtime/tests"
        parent.mkdir(parents=True, exist_ok=True)
        self.directory = tempfile.TemporaryDirectory(dir=parent)
        self.path = Path(self.directory.name) / "test.sqlite3"
        self.app = create_app(self.path, TOKEN)
        self.client = TestClient(self.app)
        self.addCleanup(self.directory.cleanup)
        self.addCleanup(self.client.close)

    def headers(self, customer=TARAS, business=BUSINESS_ID):
        return {"Authorization": "Bearer " + TOKEN, "X-Customer-Id": customer, "X-Business-Id": business}

    def journal(self):
        response = self.client.get("/admin/journal", headers={"Authorization": "Bearer " + TOKEN})
        self.assertEqual(response.status_code, 200)
        return response.json()

    def freeze(self, key=None, customer=MARTA, account="acct-marta-004", reason="customer_request"):
        return self.client.post(f"/accounts/{account}/card/freeze", headers=self.headers(customer) | {"Idempotency-Key": key or str(uuid4())}, json={"reason": reason})

    def test_real_generated_openapi_is_bounded_and_excludes_admin_and_authorization_input(self):
        response = self.client.get("/openapi.json")
        self.assertEqual(response.status_code, 200)
        spec = response.json()
        self.assertTrue(spec["openapi"].startswith("3.1."))
        self.assertEqual(len(spec["paths"]), 5)
        self.assertNotIn("/admin/journal", spec["paths"])
        self.assertNotIn("/health", spec["paths"])
        def inspect(node):
            if isinstance(node, dict):
                self.assertTrue(set(node).isdisjoint({"anyOf", "allOf", "oneOf"}))
                for value in node.values():
                    inspect(value)
            elif isinstance(node, list):
                for value in node:
                    inspect(value)
        inspect(spec)
        for item in spec["paths"].values():
            for operation in item.values():
                headers = {row["name"] for row in operation.get("parameters", []) if row["in"] == "header"}
                self.assertTrue({"X-Customer-Id", "X-Business-Id"} <= headers)
                self.assertNotIn("Authorization", headers)
        models = spec["components"]["schemas"]
        self.assertTrue(all(model.get("additionalProperties") is False for model in models.values()))

    def test_authentication_failures_and_hidden_journal_access_make_no_effect_or_journal_entry(self):
        for headers in ({}, {"Authorization": "Bearer incorrect"}, {"Authorization": "Basic incorrect"}):
            with self.subTest(headers=bool(headers)):
                self.assertEqual(self.client.get("/accounts/acct-taras-002/balance", headers=headers).status_code, 401)
                self.assertEqual(self.client.post("/accounts/acct-marta-004/card/freeze", headers=headers, json={"reason": "customer_request"}).status_code, 401)
                self.assertEqual(self.client.get("/admin/journal", headers=headers).status_code, 401)
        self.assertEqual(self.journal()["last_sequence"], 0)
        self.assertEqual(self.journal()["effect_count"], 0)
        self.assertEqual(self.client.get("/health").json()["source"], SOURCE)

    def test_cross_customer_foreign_business_missing_mapping_and_unknown_object_are_denied_without_changes(self):
        foreign = "b1000000-0000-4000-8000-000000000099"
        for customer, business, account in [(MARTA, BUSINESS_ID, "acct-taras-002"), (TARAS, foreign, "acct-taras-002"), (str(uuid4()), BUSINESS_ID, "acct-taras-002"), (TARAS, BUSINESS_ID, "acct-unknown")]:
            headers = self.headers(customer, business)
            self.assertEqual(self.client.get(f"/accounts/{account}/balance", headers=headers).status_code, 404)
            self.assertEqual(self.client.post(f"/accounts/{account}/card/freeze", headers=headers | {"Idempotency-Key": str(uuid4())}, json={"reason": "customer_request"}).status_code, 404)
        self.assertEqual(self.journal()["last_sequence"], 0)
        self.assertEqual(self.journal()["effect_count"], 0)

    def test_reads_return_unique_verifiable_receipts_and_separate_read_count_from_effects(self):
        values = []
        for suffix in ("", "/balance", "/transactions"):
            response = self.client.get("/accounts/acct-taras-002" + suffix, headers=self.headers())
            self.assertEqual(response.status_code, 200)
            values.append(response.json())
        self.assertEqual(values[1]["balance_cents"], 3754217)
        self.assertEqual(values[1]["currency"], "UAH")
        self.assertEqual(values[1]["source"], SOURCE)
        receipts = [value[0]["receipt_id"] if isinstance(value, list) else value["receipt_id"] for value in values]
        self.assertEqual(len(set(receipts)), 3)
        journal = self.journal()
        self.assertEqual((journal["read_count"], journal["effect_count"], journal["replay_count"]), (3, 0, 0))
        self.assertEqual([row["sequence"] for row in journal["entries"]], [1, 2, 3])
        self.assertEqual([row["receipt_id"] for row in journal["entries"]], receipts)
        self.assertNotIn(TOKEN, json.dumps(journal))
        self.assertNotIn("description", json.dumps(journal))

    def test_concurrent_same_key_freeze_commits_one_effect_and_stable_effect_identity(self):
        key = str(uuid4())
        def execute(_):
            with TestClient(self.app) as client:
                return client.post("/accounts/acct-marta-004/card/freeze", headers=self.headers(MARTA) | {"Idempotency-Key": key}, json={"reason": "customer_request"})
        with ThreadPoolExecutor(max_workers=5) as pool:
            responses = list(pool.map(execute, range(5)))
        self.assertTrue(all(response.status_code == 200 for response in responses))
        values = [response.json() for response in responses]
        self.assertEqual(len({value["effect_id"] for value in values}), 1)
        self.assertEqual(len({value["receipt_id"] for value in values}), 5)
        self.assertEqual(sum(not value["replayed"] for value in values), 1)
        journal = self.journal()
        self.assertEqual((journal["effect_count"], journal["replay_count"]), (1, 4))
        self.assertEqual({row["correlation_id"] for row in journal["entries"]}, {key})
        self.assertEqual([row["sequence"] for row in journal["entries"]], list(range(1, 6)))

    def test_conflicting_key_or_second_effect_is_rejected_without_extra_mutation(self):
        key = str(uuid4())
        self.assertEqual(self.freeze(key).status_code, 200)
        self.assertEqual(self.freeze(key, reason="security_precaution").status_code, 409)
        self.assertEqual(self.freeze().status_code, 409)
        self.assertEqual(self.journal()["effect_count"], 1)
        self.assertEqual(self.journal()["last_sequence"], 1)

    def test_strict_input_and_canonical_key_validation_do_not_mutate(self):
        headers = self.headers(MARTA) | {"Idempotency-Key": str(uuid4())}
        for body in ({"reason": "customer_request", "extra": True}, {"reason": 1}, {"reason": "anything"}, {}):
            response = self.client.post("/accounts/acct-marta-004/card/freeze", headers=headers, json=body)
            self.assertEqual(response.status_code, 422)
            self.assertEqual(response.json(), {"error": "invalid_request"})
        self.assertEqual(self.freeze("not-a-uuid").status_code, 422)
        self.assertEqual(self.journal()["last_sequence"], 0)

    def test_close_is_a_scoped_synthetic_state_change_with_idempotency_not_a_money_effect(self):
        key = str(uuid4())
        headers = self.headers(ANDRII) | {"Idempotency-Key": key}
        path = "/accounts/acct-andrii-005/close"
        first = self.client.post(path, headers=headers, json={"reason": "account_cleanup"})
        second = self.client.post(path, headers=headers, json={"reason": "account_cleanup"})
        self.assertEqual((first.status_code, second.status_code), (200, 200))
        self.assertEqual(first.json()["effect_id"], second.json()["effect_id"])
        self.assertTrue(second.json()["replayed"])
        balance = self.client.get("/accounts/acct-andrii-005/balance", headers=self.headers(ANDRII)).json()
        self.assertEqual(balance["balance_cents"], 158900)
        self.assertEqual(self.journal()["effect_count"], 1)

    def test_reset_and_path_guards_preserve_unowned_data(self):
        self.assertEqual(self.freeze().status_code, 200)
        self.app.state.store.initialize(reset=True)
        self.assertEqual(self.journal()["last_sequence"], 0)
        self.assertEqual(self.freeze().status_code, 200)
        unowned = Path(self.directory.name) / "unowned.sqlite3"
        with closing(sqlite3.connect(unowned)) as conn:
            conn.execute("CREATE TABLE private_rows(value TEXT)")
            conn.execute("INSERT INTO private_rows VALUES('preserve')")
            conn.commit()
        with self.assertRaises(RuntimeError):
            Store(unowned)
        with closing(sqlite3.connect(unowned)) as conn:
            self.assertEqual(conn.execute("SELECT value FROM private_rows").fetchone()[0], "preserve")
        with self.assertRaises(RuntimeError):
            Store(ROOT.parent / "refuse-outside.sqlite3")


if __name__ == "__main__":
    unittest.main()
