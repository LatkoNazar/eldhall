# Private external FastAPI banking lab

This standalone directory is outside the Eldhall repository. All records are fictional and map only to the explicitly selected synthetic bank/customers. No support PostgreSQL, provider SDK, dotenv loader, root environment file or money-moving operation is used.

Pinned dependency versions were verified from official PyPI metadata; `uv.lock` is the installation source of truth. FastAPI produces the real `/openapi.json`; `.runtime/openapi.json` is downloaded from the running server, not a hand-authored substitute.

```powershell
cd D:/eldhall-bank-api-lab
uv sync --locked
uv run --locked python -m unittest discover -s tests -v
uv run --locked python -m bank_api_lab
```

The launcher takes no arguments and binds only `127.0.0.1:8101`. It ignores ambient host/database/provider settings. `/health` is public; business endpoints and `/admin/journal` require the upstream bearer from `.runtime/credentials.env`. The other key in that file is exclusively for the MCP sidecar; it is a distinct credential. Never print the file, place tokens in command arguments, or commit them.

Scope headers are `X-Business-Id` and `X-Customer-Id`; they must match the object owner. The upstream bearer is read from `Request`, so no required arbitrary Authorization header is generated as model input. Mutations require a canonical UUID `Idempotency-Key`, atomically deduplicate the exact operation/resource/body, and reject conflicting reuse. The key is the durable Eldhall proposal ID in actual MCP use.

Operations: `get_account`, `get_balance`, `list_transactions`, `freeze_card`, `close_account`. Taras's `acct-taras-002` balance is exactly **3,754,217 cents UAH / 37,542.17 UAH**. Marta has `acct-marta-004` for an `ask` freeze, Andrii `acct-andrii-005` for a denied close. `review.json` exposes exactly these operations, injects trusted scope and projects only approved output fields. It does not grant permissions. Root creates `.runtime/manifest.json` and `.runtime/support.config.json`; the separate sidecar uses port8102. No MCP sidecar is launched by this project.

Every successful call returns `source=external-fastapi-lab` and a unique `receipt_id`. The auth-protected admin journal is excluded from OpenAPI/review. Its monotonically increasing sequence distinguishes `read`, actual `mutation`, and idempotent `replay`. `effect_count` counts only real synthetic state transitions; replay keeps the same `effect_id` and adds no second effect. Journal records contain safe IDs/enums, not tokens, raw requests, model text or transaction descriptions.

After stopping only this owned lab process, `uv run --locked python -m bank_api_lab.seed --reset` resets **only** `.runtime/bank.sqlite3`, refuses unowned/mismatched schema, and never connects to support DB. Do not reset while acceptance evidence is being collected. Tests use separate temporary owned lab databases under `.runtime/tests`, never the running lab's file.
