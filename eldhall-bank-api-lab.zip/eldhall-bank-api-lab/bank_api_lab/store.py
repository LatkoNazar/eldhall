import hashlib
import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from uuid import uuid4

from .config import BUSINESS_ID, FIXTURES, OWNER, ROOT, SOURCE


class LabError(Exception):
    def __init__(self, status: int, code: str):
        self.status, self.code = status, code


class Store:
    """One owned SQLite file. Every business effect and its idempotency receipt commit together."""
    def __init__(self, path: Path):
        self.path = path.resolve()
        if not self.path.is_relative_to((ROOT / ".runtime").resolve()):
            raise RuntimeError("Lab database must stay inside its owned runtime directory")
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.initialize()

    @contextmanager
    def connection(self):
        conn = sqlite3.connect(self.path, timeout=10)
        conn.row_factory = sqlite3.Row
        try:
            conn.execute("BEGIN IMMEDIATE")
            yield conn
            conn.commit()
        except BaseException:
            conn.rollback()
            raise
        finally:
            conn.close()

    def initialize(self, reset: bool = False):
        with self.connection() as conn:
            tables = {r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")}
            if tables:
                owner = conn.execute("SELECT value FROM metadata WHERE key='owner'").fetchone() if "metadata" in tables else None
                if owner is None or owner[0] != OWNER:
                    raise RuntimeError("Refusing to use an unowned database")
                if tables != {"metadata", "accounts", "transactions", "idempotency", "journal"}:
                    raise RuntimeError("Unexpected lab database schema")
                if not reset:
                    return
                for table in ("journal", "idempotency", "transactions", "accounts"):
                    conn.execute(f"DELETE FROM {table}")
                conn.execute("DELETE FROM sqlite_sequence WHERE name='journal'")
            else:
                for sql in [
                    "CREATE TABLE metadata(key TEXT PRIMARY KEY,value TEXT NOT NULL)",
                    "CREATE TABLE accounts(account_id TEXT PRIMARY KEY,business_id TEXT NOT NULL,customer_id TEXT NOT NULL,account_label TEXT NOT NULL,balance_cents INTEGER NOT NULL,currency TEXT NOT NULL,status TEXT NOT NULL,card_id TEXT NOT NULL,card_status TEXT NOT NULL)",
                    "CREATE TABLE transactions(transaction_id TEXT PRIMARY KEY,account_id TEXT NOT NULL,posted_at TEXT NOT NULL,description TEXT NOT NULL,amount_cents INTEGER NOT NULL,currency TEXT NOT NULL,status TEXT NOT NULL)",
                    "CREATE TABLE idempotency(business_id TEXT NOT NULL,customer_id TEXT NOT NULL,key TEXT NOT NULL,operation TEXT NOT NULL,resource_id TEXT NOT NULL,payload_hash TEXT NOT NULL,response TEXT NOT NULL,PRIMARY KEY(business_id,customer_id,key))",
                    "CREATE TABLE journal(sequence INTEGER PRIMARY KEY AUTOINCREMENT,receipt_id TEXT NOT NULL UNIQUE,kind TEXT NOT NULL,operation TEXT NOT NULL,business_id TEXT NOT NULL,customer_id TEXT NOT NULL,resource_id TEXT NOT NULL,effect_id TEXT NOT NULL,correlation_id TEXT NOT NULL)",
                ]:
                    conn.execute(sql)
                conn.execute("INSERT INTO metadata VALUES('owner',?)", (OWNER,))
            fixture = json.loads(FIXTURES.read_text(encoding="utf-8"))
            if fixture["version"] != 1 or fixture["business_id"] != BUSINESS_ID:
                raise RuntimeError("Invalid synthetic fixture identity")
            for customer in fixture["customers"]:
                conn.execute("INSERT INTO accounts VALUES(?,?,?,?,?,?,?,?,?)", (customer["account_id"], BUSINESS_ID, customer["customer_id"], customer["account_label"], customer["balance_cents"], "UAH", "open", customer["card_id"], "active"))
                for tx in customer["transactions"]:
                    conn.execute("INSERT INTO transactions VALUES(?,?,?,?,?,?,?)", (tx["transaction_id"], customer["account_id"], tx["posted_at"], tx["description"], tx["amount_cents"], "UAH", "posted"))

    @staticmethod
    def account(conn, account_id, business_id, customer_id):
        row = conn.execute("SELECT * FROM accounts WHERE account_id=? AND business_id=? AND customer_id=?", (account_id, business_id, customer_id)).fetchone()
        if row is None:
            raise LabError(404, "account_not_found")
        return dict(row)

    @staticmethod
    def record(conn, kind, operation, business_id, customer_id, resource_id, effect_id="", correlation_id=""):
        receipt = "rcpt-" + str(uuid4())
        conn.execute("INSERT INTO journal(receipt_id,kind,operation,business_id,customer_id,resource_id,effect_id,correlation_id) VALUES(?,?,?,?,?,?,?,?)", (receipt, kind, operation, business_id, customer_id, resource_id, effect_id, correlation_id))
        return receipt

    def read(self, operation, account_id, business_id, customer_id):
        with self.connection() as conn:
            account = self.account(conn, account_id, business_id, customer_id)
            receipt = self.record(conn, "read", operation, business_id, customer_id, account_id)
            common = {"source": SOURCE, "receipt_id": receipt}
            if operation == "get_account":
                return {key: account[key] for key in ("account_id", "account_label", "currency", "status", "card_id", "card_status")} | common
            if operation == "get_balance":
                return {key: account[key] for key in ("account_id", "balance_cents", "currency")} | common
            if operation == "list_transactions":
                return [dict(row) | common for row in conn.execute("SELECT transaction_id,posted_at,description,amount_cents,currency,status FROM transactions WHERE account_id=? ORDER BY transaction_id LIMIT 50", (account_id,))]
            raise RuntimeError("Unknown registered lab read")

    def mutate(self, operation, account_id, business_id, customer_id, key, payload):
        payload_hash = hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
        with self.connection() as conn:
            account = self.account(conn, account_id, business_id, customer_id)
            prior = conn.execute("SELECT * FROM idempotency WHERE business_id=? AND customer_id=? AND key=?", (business_id, customer_id, key)).fetchone()
            if prior:
                if prior["operation"] != operation or prior["resource_id"] != account_id or prior["payload_hash"] != payload_hash:
                    raise LabError(409, "idempotency_conflict")
                result = json.loads(prior["response"])
                receipt = self.record(conn, "replay", operation, business_id, customer_id, account_id, result["effect_id"], key)
                return result | {"receipt_id": receipt, "replayed": True}
            if account["status"] != "open":
                raise LabError(409, "account_not_open")
            effect_id = "effect-" + str(uuid4())
            if operation == "freeze_card":
                if account["card_status"] != "active":
                    raise LabError(409, "card_already_frozen")
                conn.execute("UPDATE accounts SET card_status='frozen' WHERE account_id=?", (account_id,))
                result = {"account_id": account_id, "card_id": account["card_id"], "status": "frozen", "effect_id": effect_id, "source": SOURCE}
            elif operation == "close_account":
                conn.execute("UPDATE accounts SET status='closed' WHERE account_id=?", (account_id,))
                result = {"account_id": account_id, "status": "closed", "effect_id": effect_id, "source": SOURCE}
            else:
                raise RuntimeError("Unknown registered lab mutation")
            receipt = self.record(conn, "mutation", operation, business_id, customer_id, account_id, effect_id, key)
            conn.execute("INSERT INTO idempotency VALUES(?,?,?,?,?,?,?)", (business_id, customer_id, key, operation, account_id, payload_hash, json.dumps(result, sort_keys=True)))
            return result | {"receipt_id": receipt, "replayed": False}

    def journal(self, after=0):
        with self.connection() as conn:
            rows = [dict(row) for row in conn.execute("SELECT * FROM journal WHERE sequence>? ORDER BY sequence LIMIT 200", (after,))]
            counts = {row["kind"]: row["n"] for row in conn.execute("SELECT kind,COUNT(*) AS n FROM journal GROUP BY kind")}
            last = conn.execute("SELECT COALESCE(MAX(sequence),0) FROM journal").fetchone()[0]
            return {"source": SOURCE, "entries": rows, "last_sequence": last, "has_more": len(rows) == 200 and rows[-1]["sequence"] < last, "read_count": counts.get("read", 0), "effect_count": counts.get("mutation", 0), "replay_count": counts.get("replay", 0)}
