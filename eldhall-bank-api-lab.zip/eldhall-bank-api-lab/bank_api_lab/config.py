from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATABASE = ROOT / ".runtime" / "bank.sqlite3"
FIXTURES = ROOT / "fixtures.json"
CREDENTIALS = ROOT / ".runtime" / "credentials.env"
BUSINESS_ID = "b1000000-0000-4000-8000-000000000001"
SOURCE = "external-fastapi-lab"
OWNER = "eldhall-bank-api-lab/v1"


def load_upstream_token() -> str:
    """Read only the selected private file; never dotenv or ambient process settings."""
    entries = {}
    for line in CREDENTIALS.read_text(encoding="utf-8").splitlines():
        key, separator, value = line.partition("=")
        if not separator or key in entries:
            raise RuntimeError("Invalid lab credential file")
        entries[key] = value
    expected = {"BANK_LAB_UPSTREAM_TOKEN", "BANK_LAB_MCP_SERVICE_TOKEN"}
    if set(entries) != expected or any(len(entries[key]) < 32 for key in expected):
        raise RuntimeError("Invalid lab credential file")
    if entries["BANK_LAB_UPSTREAM_TOKEN"] == entries["BANK_LAB_MCP_SERVICE_TOKEN"]:
        raise RuntimeError("Lab credentials must be distinct")
    return entries["BANK_LAB_UPSTREAM_TOKEN"]
