import sys

from .config import DATABASE
from .store import Store

if __name__ == "__main__":
    if sys.argv[1:] != ["--reset"]:
        raise SystemExit("Only --reset is supported; stop this owned lab process first")
    Store(DATABASE).initialize(reset=True)
    print("Synthetic lab fixtures reset; only the owned lab SQLite file was changed")
