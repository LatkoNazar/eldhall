import hmac
from pathlib import Path
from typing import Annotated, Literal
from uuid import UUID

from fastapi import APIRouter, Depends, FastAPI, Header, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from pydantic import BaseModel, ConfigDict, Field

from .config import SOURCE
from .store import LabError, Store


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", strict=True)


class ErrorResponse(StrictModel):
    error: str = Field(max_length=100)


class FreezeCard(StrictModel):
    reason: Literal["customer_request", "security_precaution"]


class CloseAccount(StrictModel):
    reason: Literal["customer_request", "account_cleanup"]


class AccountResponse(StrictModel):
    account_id: str
    account_label: str
    currency: str
    status: str
    card_id: str
    card_status: str
    source: str
    receipt_id: str


class BalanceResponse(StrictModel):
    account_id: str
    balance_cents: int
    currency: str
    source: str
    receipt_id: str


class TransactionResponse(StrictModel):
    transaction_id: str
    posted_at: str
    description: str
    amount_cents: int
    currency: str
    status: str
    source: str
    receipt_id: str


class FreezeResponse(StrictModel):
    account_id: str
    card_id: str
    status: str
    effect_id: str
    source: str
    receipt_id: str
    replayed: bool


class CloseResponse(StrictModel):
    account_id: str
    status: str
    effect_id: str
    source: str
    receipt_id: str
    replayed: bool


ERRORS = {status: {"model": ErrorResponse} for status in (401, 404, 409, 422)}
Customer = Annotated[str, Header(alias="X-Customer-Id", max_length=200)]
Business = Annotated[str, Header(alias="X-Business-Id", max_length=200)]
Key = Annotated[str, Header(alias="Idempotency-Key", max_length=36)]


def create_app(database_path: Path, upstream_token: str) -> FastAPI:
    if len(upstream_token) < 32:
        raise RuntimeError("Lab bearer is not configured")
    store = Store(database_path)
    app = FastAPI(title="Eldhall external synthetic banking lab", version="0.1.0", description="Private synthetic records only. No real banking or money effects.")
    app.state.store = store

    @app.exception_handler(LabError)
    async def lab_error(_request: Request, error: LabError):
        return JSONResponse({"error": error.code}, status_code=error.status)

    @app.exception_handler(RequestValidationError)
    async def invalid_request(_request: Request, _error: RequestValidationError):
        return JSONResponse({"error": "invalid_request"}, status_code=422)

    def authorize(request: Request):
        if not hmac.compare_digest(request.headers.get("authorization", "").encode(), ("Bearer " + upstream_token).encode()):
            raise LabError(401, "unauthorized")

    def canonical_key(key: str):
        try:
            if str(UUID(key)) != key:
                raise ValueError()
        except ValueError:
            raise LabError(422, "invalid_idempotency_key") from None
        return key

    router = APIRouter(dependencies=[Depends(authorize)], responses=ERRORS)

    @app.get("/health", include_in_schema=False)
    def health():
        return {"status": "ok", "source": SOURCE, "store": "sqlite-owned-lab", "synthetic": True}

    @router.get("/accounts/{account_id}", operation_id="get_account", tags=["Accounts"], response_model=AccountResponse)
    def get_account(account_id: str, x_customer_id: Customer, x_business_id: Business):
        return store.read("get_account", account_id, x_business_id, x_customer_id)

    @router.get("/accounts/{account_id}/balance", operation_id="get_balance", tags=["Accounts"], response_model=BalanceResponse)
    def get_balance(account_id: str, x_customer_id: Customer, x_business_id: Business):
        return store.read("get_balance", account_id, x_business_id, x_customer_id)

    @router.get("/accounts/{account_id}/transactions", operation_id="list_transactions", tags=["Accounts"], response_model=list[TransactionResponse])
    def list_transactions(account_id: str, x_customer_id: Customer, x_business_id: Business):
        return store.read("list_transactions", account_id, x_business_id, x_customer_id)

    @router.post("/accounts/{account_id}/card/freeze", operation_id="freeze_card", tags=["Cards"], response_model=FreezeResponse)
    def freeze_card(account_id: str, body: FreezeCard, x_customer_id: Customer, x_business_id: Business, idempotency_key: Key):
        return store.mutate("freeze_card", account_id, x_business_id, x_customer_id, canonical_key(idempotency_key), body.model_dump())

    @router.post("/accounts/{account_id}/close", operation_id="close_account", tags=["Accounts"], response_model=CloseResponse)
    def close_account(account_id: str, body: CloseAccount, x_customer_id: Customer, x_business_id: Business, idempotency_key: Key):
        return store.mutate("close_account", account_id, x_business_id, x_customer_id, canonical_key(idempotency_key), body.model_dump())

    @router.get("/admin/journal", include_in_schema=False)
    def journal(after: int = 0):
        if after < 0:
            raise LabError(422, "invalid_sequence")
        return store.journal(after)

    app.include_router(router)
    return app
