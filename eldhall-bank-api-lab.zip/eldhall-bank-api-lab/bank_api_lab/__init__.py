"""Synthetic external banking lab; no Eldhall or provider dependencies."""
