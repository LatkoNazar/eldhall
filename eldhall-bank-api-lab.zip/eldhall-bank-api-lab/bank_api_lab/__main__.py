import json
import os
import sys

import uvicorn

from .app import create_app
from .config import DATABASE, load_upstream_token


def main() -> int:
    if len(sys.argv) != 1:
        print("Lab launcher accepts no arguments", file=sys.stderr)
        return 2
    app = create_app(DATABASE, load_upstream_token())
    print(json.dumps({"status": "starting", "pid": os.getpid(), "url": "http://127.0.0.1:8101", "source": "external-fastapi-lab"}), flush=True)
    uvicorn.run(app, host="127.0.0.1", port=8101, access_log=False, log_level="warning")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
